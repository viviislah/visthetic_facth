export interface MusicTrackPreset {
  id: string;
  title: string;
  artist: string;
}

export const PRESET_MUSIC_TRACKS: MusicTrackPreset[] = [];
